# Transfer Learning ResNet18 — Klasifikasi Citra Sampah

Notebook praktikum dijalankan di Google Colab. Notebook utama membandingkan mode `feature`, `partial`, dan `scratch` pada ResNet18.

## Dataset
- Kelas: cardboard, glass, metal, paper, plastic, trash
- Training: 790 gambar; validation: 176 gambar; test: 171 gambar.
- Input: 224×224; batch size: 16; epoch: 10; seed: 42.

## Ringkasan evaluasi
| Mode | Best epoch | Best val accuracy | Test accuracy | Weighted F1 | Waktu (detik) |
|---|---:|---:|---:|---:|---:|
| feature | 10 | 81.82% | 79.53% | 79.64% | 66.4 |
| partial | 7 | 89.20% | 84.80% | 84.81% | 61.8 |
| scratch | 7 | 52.84% | 56.73% | 56.80% | 67.4 |

Mode yang dipilih berdasarkan validation accuracy: **partial** (validation accuracy 89.20%). Pemilihan tidak menggunakan test accuracy.

## Artefak
- `perbandingan_metrik.csv`: metrik test dan waktu training untuk tiap mode.
- `riwayat_epoch.csv`: loss dan akurasi train/validation per epoch.
- `classification_report.csv`: precision, recall, F1 per kelas dan agregat.
- `analisis_kesalahan.csv`: daftar sampel test yang salah diprediksi oleh mode terpilih.
- `akurasi_per_epoch.png`, `loss_per_epoch.png`, `confusion_matrix_test.png`: grafik evaluasi.

> Catatan: hasil ini berasal dari run yang terekam pada notebook Colab. Bila notebook dijalankan ulang, nilai metrik dan waktu dapat berubah.
